class Config {
  static String appName = 'E-commerce';
  static String appDescription = 'Makeup Store App';
  static String userName = 'Chaitanya';
  static String userEmail = 'chaitanya@gmail.com';
  static String collectionName = 'Maybelline Collection';

  /// Json files
  static String getProductsJson = 'assets/json/get-product.json';
  static String brandsJson = 'assets/json/brands.json';
}
