part of 'cart_bloc.dart';

@immutable
abstract class CartEvent {}

class CartStart extends CartEvent{}

