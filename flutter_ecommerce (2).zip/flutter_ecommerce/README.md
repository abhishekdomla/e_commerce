# Flutter E-commerce X 

A flutter E-commerce app template.

## Screenshots
![Screenshot_1](https://user-images.githubusercontent.com/111413480/213930626-d59cc147-1294-43d8-baf0-011348f127c3.jpg)
![Screenshot_2](https://user-images.githubusercontent.com/111413480/213930656-13329dc6-3a01-4a01-b5fa-e89f5e8d3899.jpg)
![Screenshot_3](https://user-images.githubusercontent.com/111413480/213930674-e7ff38a0-a9d9-4a4a-998f-fd41f783ae6a.jpg)
![Screenshot_4](https://user-images.githubusercontent.com/111413480/213930691-a87a6e9b-3b7e-4c2d-8e0b-af4bc3a1112d.jpg)
![Screenshot_5](https://user-images.githubusercontent.com/111413480/213930716-b2f3fbd3-adc9-45c1-ac53-69a990f38860.jpg)
![Screenshot_6](https://user-images.githubusercontent.com/111413480/213930733-e3c9de65-f6c0-4063-891f-0d7c26ff4b7e.jpg)
![Screenshot_7](https://user-images.githubusercontent.com/111413480/213930739-010aef8c-7fa8-485b-bdb0-a5d8171359bf.jpg)
![Screenshot_8](https://user-images.githubusercontent.com/111413480/213930749-f804f4e9-38a9-4ca0-b446-f0c112aaf24e.jpg)

### Screens

Intro , Home , Cart , Profile , Search , Checkout , Payment , Login$SignUp , Favorits , Order history , User Address , Shoping

### Development Notice

1- Clone project with https://github.com/EmirBashiri/Flutter-E-commerce-X.git

2- Run flutter pub get in terminal

3- Run flutter run in terminal and enjoy
